const MEMBER_TOKEN_KEY = "deliver_member_token_v1";
const LANDING_PAGE_PATH = "../랜딩페이지-LandingPage/index.html";

const ORDER_STATUS_LABELS = {
  received: "접수",
  reviewing: "검수중",
  queued: "송출대기",
  published: "송출완료",
  rejected: "반려",
};

const state = {
  member: null,
  media: [],
  orders: [],
  mediaFilter: "",
  selectedMediaId: "",
  activeMediaGroup: "",
  mediaCollapsed: {},
  syncTimer: null,
};

function clearLegacyTokenStorage() {
  try {
    localStorage.removeItem(MEMBER_TOKEN_KEY);
  } catch (error) {
  }
  try {
    sessionStorage.removeItem(MEMBER_TOKEN_KEY);
  } catch (error) {
  }
}

function redirectToLanding() {
  window.location.replace(LANDING_PAGE_PATH);
}

function formatCurrency(value) {
  const n = Number(value || 0);
  if (!Number.isFinite(n)) return "0원";
  return `${Math.round(n).toLocaleString("ko-KR")}원`;
}

function formatDate(value) {
  try {
    return new Date(value).toLocaleString("ko-KR");
  } catch (error) {
    return "-";
  }
}

function formatBytes(value) {
  const n = Number(value || 0);
  if (!Number.isFinite(n) || n <= 0) return "-";
  if (n < 1024) return `${n}B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)}KB`;
  return `${(n / (1024 * 1024)).toFixed(1)}MB`;
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

async function apiFetch(path, init = {}) {
  const headers = { ...(init.headers || {}) };
  const method = String(init.method || "GET").toUpperCase();
  if (!["GET", "HEAD", "OPTIONS"].includes(method)) {
    const csrf = getCookieValue("deliver_csrf");
    if (csrf) headers["x-csrf-token"] = csrf;
  }
  const response = await fetch(path, { ...init, headers, credentials: "same-origin" });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || data.ok === false) {
    const error = new Error(data.message || `API ${response.status}`);
    error.status = response.status;
    throw error;
  }
  return data;
}

function getCookieValue(name) {
  const source = String(document.cookie || "");
  const target = `${String(name || "")}=`;
  const part = source
    .split(";")
    .map((item) => item.trim())
    .find((item) => item.startsWith(target));
  if (!part) return "";
  return decodeURIComponent(part.slice(target.length));
}

function setOrderMessage(type, text) {
  const message = document.getElementById("order-message");
  if (!message) return;
  message.className = type ? `form-message ${type}` : "form-message";
  message.textContent = text || "";
}

function getSelectedMedia() {
  return state.media.find((item) => item.id === state.selectedMediaId) || null;
}

function getSelectedMediaBudget() {
  const media = getSelectedMedia();
  const n = Number(media?.unitPrice || 0);
  if (!Number.isFinite(n) || n <= 0) return 0;
  return Math.round(n);
}

function syncBudgetInput() {
  const budgetInput = document.getElementById("order-budget");
  if (!budgetInput) return;
  const budget = getSelectedMediaBudget();
  budgetInput.value = budget > 0 ? String(budget) : "";
}

function getFilteredMedia() {
  const query = state.mediaFilter.trim().toLowerCase();
  return state.media.filter((item) => {
    if (!query) return true;
    const text = `${item.name} ${item.category} ${item.channel}`.toLowerCase();
    return text.includes(query);
  });
}

function getMediaGroups(mediaItems) {
  const map = new Map();
  mediaItems.forEach((item) => {
    const key = String(item.category || "기타").trim() || "기타";
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(item);
  });
  return Array.from(map.entries()).sort((a, b) => a[0].localeCompare(b[0], "ko-KR"));
}

function scrollToMediaGroup(groupName) {
  const container = document.getElementById("media-group-list");
  if (!container) return;
  const groups = container.querySelectorAll(".media-group");
  let target = null;
  groups.forEach((group) => {
    if (group instanceof HTMLElement && group.dataset.groupName === groupName) {
      target = group;
    }
  });
  if (!container || !target) return;
  container.scrollTo({
    top: Math.max(0, target.offsetTop - 6),
    behavior: "smooth",
  });
}

function renderMemberState() {
  const element = document.getElementById("member-state");
  if (!element) return;
  element.textContent = state.member ? `${state.member.name} (${state.member.loginId})` : "로그인 필요";
}

function renderStats() {
  const pending = state.orders.filter((order) => !["published", "rejected"].includes(String(order.status || ""))).length;
  const published = state.orders.filter((order) => String(order.status || "") === "published").length;

  document.getElementById("stat-points").textContent = formatCurrency(state.member?.pointBalance || 0);
  document.getElementById("stat-orders-total").textContent = String(state.orders.length);
  document.getElementById("stat-orders-pending").textContent = String(pending);
  document.getElementById("stat-orders-published").textContent = String(published);
}

function renderMediaGroups() {
  const nav = document.getElementById("media-group-nav");
  const list = document.getElementById("media-group-list");
  const summary = document.getElementById("media-summary");
  if (!nav || !list) return;

  const filtered = getFilteredMedia();
  const groups = getMediaGroups(filtered);
  if (!groups.length) {
    nav.innerHTML = "";
    if (summary) summary.textContent = "매체 0개";
    list.innerHTML = `<div class="media-empty">조건에 맞는 매체가 없습니다.</div>`;
    return;
  }

  const groupNames = groups.map(([group]) => group);
  if (!groupNames.includes(state.activeMediaGroup)) {
    state.activeMediaGroup = groupNames[0];
  }
  if (summary) {
    summary.textContent = `총 ${filtered.length}개 · 카테고리 ${groupNames.length}개`;
  }

  nav.innerHTML = groups
    .map(([group, items]) => {
      const active = group === state.activeMediaGroup;
      return `<button class="media-nav-btn ${active ? "active" : ""}" type="button" data-group-nav="${escapeHtml(group)}">${escapeHtml(group)} (${items.length})</button>`;
    })
    .join("");

  list.innerHTML = groups
    .map(([group, items]) => {
      const isActive = group === state.activeMediaGroup;
      const collapsed = state.mediaFilter ? false : isActive ? false : Boolean(state.mediaCollapsed[group]);
      const rows = items
        .map((item) => {
          const selected = item.id === state.selectedMediaId;
          return `<div class="media-item ${selected ? "selected" : ""}" data-select-media="${escapeHtml(item.id)}">
            <div class="media-item-main">
              <div class="media-item-name">${escapeHtml(item.name)}</div>
              <div class="media-item-meta">단가: ${escapeHtml(item.memberPrice || formatCurrency(item.unitPrice))} · 노출: ${escapeHtml(item.channel || "-")}</div>
            </div>
            <button class="btn btn-light small" type="button" data-select-media="${escapeHtml(item.id)}">선택</button>
          </div>`;
        })
        .join("");
      return `<section class="media-group ${collapsed ? "collapsed" : ""} ${isActive ? "active" : ""}" data-group-name="${escapeHtml(group)}">
        <button class="media-group-head" type="button" data-toggle-group="${escapeHtml(group)}">
          <strong>${escapeHtml(group)}</strong>
          <span>${items.length}개 ${collapsed ? "펼치기" : "접기"}</span>
        </button>
        <div class="media-items">${rows}</div>
      </section>`;
    })
    .join("");
}

function renderSelectedMediaCard() {
  const media = getSelectedMedia();
  const name = document.getElementById("selected-media-name");
  const price = document.getElementById("selected-media-price");
  const channel = document.getElementById("selected-media-channel");
  const description = document.getElementById("selected-media-description");

  if (!media) {
    name.textContent = "매체를 선택해 주세요";
    price.textContent = "단가: -";
    channel.textContent = "노출채널: -";
    description.textContent = "참고사항: -";
    syncBudgetInput();
    return;
  }
  name.textContent = `${media.name} (${media.category})`;
  price.textContent = `단가: ${media.memberPrice || formatCurrency(media.unitPrice)}`;
  channel.textContent = `노출채널: ${media.channel || "-"}`;
  description.textContent = `참고사항: ${media.description || "별도 안내 없음"}`;
  syncBudgetInput();
}

function renderOrders() {
  const tbody = document.getElementById("member-orders-body");
  if (!tbody) return;
  if (!state.orders.length) {
    tbody.innerHTML = `<tr><td colspan="6">등록된 주문이 없습니다.</td></tr>`;
    return;
  }
  tbody.innerHTML = state.orders
    .map((order) => {
      const status = String(order.status || "received");
      const label = ORDER_STATUS_LABELS[status] || status;
      const attachmentName = String(order.attachmentName || "첨부파일");
      const attachmentLabel = `${attachmentName} (${formatBytes(order.attachmentSize)})`;
      const attachmentText = order.hasAttachment
        ? `<span class="file-ellipsis" title="${escapeHtml(attachmentLabel)}">${escapeHtml(attachmentLabel)}</span>`
        : "없음";
      return `<tr>
        <td>${formatDate(order.createdAt)}</td>
        <td>${escapeHtml(order.title)}</td>
        <td>${escapeHtml(order.mediaName || "-")}</td>
        <td>${formatCurrency(order.budget)}</td>
        <td class="attachment-col">${attachmentText}</td>
        <td><span class="status-badge status-${escapeHtml(status)}">${escapeHtml(label)}</span></td>
      </tr>`;
    })
    .join("");
}

function renderAll() {
  renderMemberState();
  renderStats();
  renderMediaGroups();
  renderSelectedMediaCard();
  renderOrders();
}

async function refreshData() {
  const me = await apiFetch("/api/auth/me");
  state.member = me.member;

  try {
    const media = await apiFetch("/api/media");
    state.media = Array.isArray(media.media) ? media.media.filter((item) => item.isActive !== false) : [];
  } catch (error) {
    // Keep current screen/session even if media API is temporarily unstable.
  }

  try {
    const orders = await apiFetch("/api/orders");
    state.orders = Array.isArray(orders.orders) ? orders.orders : [];
  } catch (error) {
    // Keep current screen/session even if orders API is temporarily unstable.
  }

  if (!state.selectedMediaId) {
    state.selectedMediaId = state.media[0]?.id || "";
  } else if (!state.media.some((item) => item.id === state.selectedMediaId)) {
    state.selectedMediaId = state.media[0]?.id || "";
  }
  renderAll();
}

async function submitOrder(form) {
  const media = getSelectedMedia();
  if (!media) {
    setOrderMessage("error", "매체를 먼저 선택해 주세요.");
    return;
  }
  const formData = new FormData(form);
  const title = String(formData.get("title") || "").trim();
  const budget = getSelectedMediaBudget();
  const requestNote = String(formData.get("requestNote") || "").trim();
  const draftFile = formData.get("draftFile");
  if (!title) {
    setOrderMessage("error", "주문명을 입력해 주세요.");
    return;
  }
  if (!Number.isFinite(budget) || budget <= 0) {
    setOrderMessage("error", "선택한 매체 단가 정보가 없어 주문할 수 없습니다.");
    return;
  }

  try {
    const payload = new FormData();
    payload.set("mediaId", media.id);
    payload.set("title", title);
    payload.set("budget", String(budget));
    payload.set("requestNote", requestNote);
    if (draftFile && typeof draftFile === "object" && Number(draftFile.size || 0) > 0) {
      payload.set("draftFile", draftFile);
    }
    const response = await apiFetch("/api/orders", {
      method: "POST",
      body: payload,
    });
    state.member.pointBalance = Number(response.pointBalance || state.member.pointBalance || 0);
    form.reset();
    const fileName = document.getElementById("order-file-name");
    if (fileName) fileName.textContent = "선택된 파일 없음";
    setOrderMessage("success", "주문이 등록되었습니다.");
    await refreshData();
  } catch (error) {
    setOrderMessage("error", error.message || "주문 등록 중 오류가 발생했습니다.");
  }
}

function bindEvents() {
  const searchInput = document.getElementById("media-search");
  const mediaGroupList = document.getElementById("media-group-list");
  const mediaGroupNav = document.getElementById("media-group-nav");
  const expandAll = document.getElementById("media-expand-all");
  const collapseAll = document.getElementById("media-collapse-all");
  const orderForm = document.getElementById("member-order-form");
  const logoutButton = document.getElementById("member-logout-button");
  const fileInput = document.getElementById("order-file-input");
  const fileButton = document.getElementById("order-file-button");
  const fileName = document.getElementById("order-file-name");

  searchInput?.addEventListener("input", () => {
    state.mediaFilter = String(searchInput.value || "");
    const filteredGroups = getMediaGroups(getFilteredMedia());
    if (filteredGroups.length) state.activeMediaGroup = filteredGroups[0][0];
    renderMediaGroups();
  });

  mediaGroupList?.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const toggleButton = target.closest("[data-toggle-group]");
    if (toggleButton instanceof HTMLElement) {
      const toggleGroup = toggleButton.getAttribute("data-toggle-group");
      if (!toggleGroup) return;
      state.mediaCollapsed[toggleGroup] = !Boolean(state.mediaCollapsed[toggleGroup]);
      state.activeMediaGroup = toggleGroup;
      renderMediaGroups();
      return;
    }

    const mediaTarget = target.closest("[data-select-media]");
    if (!(mediaTarget instanceof HTMLElement)) return;
    const mediaId = mediaTarget.getAttribute("data-select-media");
    if (!mediaId) return;
    state.selectedMediaId = mediaId;
    const selectedMedia = state.media.find((item) => item.id === mediaId);
    if (selectedMedia?.category) {
      state.activeMediaGroup = selectedMedia.category;
      state.mediaCollapsed[selectedMedia.category] = false;
    }
    renderMediaGroups();
    renderSelectedMediaCard();
  });

  mediaGroupNav?.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const navButton = target.closest("[data-group-nav]");
    if (!(navButton instanceof HTMLElement)) return;
    const groupName = navButton.getAttribute("data-group-nav");
    if (!groupName) return;
    state.activeMediaGroup = groupName;
    state.mediaCollapsed[groupName] = false;
    renderMediaGroups();
    scrollToMediaGroup(groupName);
  });

  expandAll?.addEventListener("click", () => {
    state.mediaCollapsed = {};
    renderMediaGroups();
  });

  collapseAll?.addEventListener("click", () => {
    const groups = getMediaGroups(getFilteredMedia());
    const next = {};
    groups.forEach(([group]) => {
      next[group] = true;
    });
    state.mediaCollapsed = next;
    if (state.activeMediaGroup) state.mediaCollapsed[state.activeMediaGroup] = false;
    renderMediaGroups();
  });

  orderForm?.addEventListener("submit", (event) => {
    event.preventDefault();
    submitOrder(orderForm);
  });

  fileButton?.addEventListener("click", () => {
    fileInput?.click();
  });

  fileInput?.addEventListener("change", () => {
    const name = fileInput.files?.[0]?.name || "";
    if (!fileName) return;
    fileName.textContent = name ? name : "선택된 파일 없음";
  });

  logoutButton?.addEventListener("click", async () => {
    try {
      await apiFetch("/api/auth/logout", { method: "POST" });
    } catch (error) {
    }
    redirectToLanding();
  });
}

async function init() {
  clearLegacyTokenStorage();
  bindEvents();
  try {
    await refreshData();
  } catch (error) {
    if (Number(error?.status) === 401) {
      redirectToLanding();
      return;
    }
    setOrderMessage("error", "데이터 로딩이 지연되고 있습니다. 잠시 후 자동으로 다시 동기화됩니다.");
    renderAll();
    return;
  }

  state.syncTimer = window.setInterval(async () => {
    try {
      await refreshData();
    } catch (error) {
      if (Number(error?.status) === 401) {
        redirectToLanding();
      }
    }
  }, 4000);
}

window.addEventListener("beforeunload", () => {
  if (state.syncTimer) window.clearInterval(state.syncTimer);
});

init();
