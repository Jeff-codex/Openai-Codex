#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
LANDING_REL_PATH="01_서비스코드-ServiceCode/랜딩페이지-LandingPage/index.html"
ADMIN_REL_PATH="01_서비스코드-ServiceCode/관리자페이지-AdminPage/index.html"
LANDING_WSL_PATH="$PROJECT_ROOT/$LANDING_REL_PATH"
ADMIN_WSL_PATH="$PROJECT_ROOT/$ADMIN_REL_PATH"

if command -v wslpath >/dev/null 2>&1; then
  LANDING_WIN_PATH="$(wslpath -w "$LANDING_WSL_PATH")"
  ADMIN_WIN_PATH="$(wslpath -w "$ADMIN_WSL_PATH")"
else
  LANDING_WIN_PATH="(wslpath unavailable)"
  ADMIN_WIN_PATH="(wslpath unavailable)"
fi

echo "[PREVIEW] 결과물 확인 경로"
echo "[PREVIEW] 랜딩 WSL 경로: $LANDING_WSL_PATH"
echo "[PREVIEW] 랜딩 Windows 경로: $LANDING_WIN_PATH"
echo "[PREVIEW] 랜딩 URL(서버 실행 시): http://localhost:4173/$LANDING_REL_PATH"
echo "[PREVIEW] 관리자 WSL 경로: $ADMIN_WSL_PATH"
echo "[PREVIEW] 관리자 Windows 경로: $ADMIN_WIN_PATH"
echo "[PREVIEW] 관리자 URL(서버 실행 시): http://localhost:4173/$ADMIN_REL_PATH"
echo "[PREVIEW] 서버 실행 명령:"
echo "  cd \"$PROJECT_ROOT\" && python3 -m http.server 4173"
