import { getBearerToken, readSession } from "../_lib/cloudflare_store.js";

export async function requireAdminSession(context) {
  const token = getBearerToken(context.request);
  const session = await readSession(context.env, token, "admin");
  if (!session?.adminId) return null;
  return session;
}
