import {
  destroySession,
  getBearerToken,
  jsonOk,
} from "../_lib/cloudflare_store.js";

export async function onRequestPost(context) {
  const token = getBearerToken(context.request);
  if (token) {
    await destroySession(context.env, token);
  }
  return jsonOk({ loggedOut: true });
}
