#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
PREVIEW_REL_PATH="01_서비스코드-ServiceCode/랜딩페이지-LandingPage/index.html"
PREVIEW_WSL_PATH="$PROJECT_ROOT/$PREVIEW_REL_PATH"

if command -v wslpath >/dev/null 2>&1; then
  PREVIEW_WIN_PATH="$(wslpath -w "$PREVIEW_WSL_PATH")"
else
  PREVIEW_WIN_PATH="(wslpath unavailable)"
fi

echo "[PREVIEW] 결과물 확인 경로"
echo "[PREVIEW] WSL 경로: $PREVIEW_WSL_PATH"
echo "[PREVIEW] Windows 경로: $PREVIEW_WIN_PATH"
echo "[PREVIEW] 브라우저 미리보기 URL(서버 실행 시): http://localhost:4173/$PREVIEW_REL_PATH"
echo "[PREVIEW] 서버 실행 명령:"
echo "  cd \"$PROJECT_ROOT\" && python3 -m http.server 4173"
