import {
  createSession,
  d1Query,
  jsonError,
  jsonOk,
  normalizeLoginId,
  parseJson,
} from "../_lib/cloudflare_store.js";

export async function onRequestPost(context) {
  try {
    const body = await parseJson(context.request);
    const loginId = normalizeLoginId(body.loginId);
    const password = String(body.password || "");

    if (!loginId || !password) {
      return jsonError("아이디와 비밀번호를 입력해 주세요.", 400);
    }

    const rows = await d1Query(
      context.env,
      "select id, login_id, name, email, role, password from members where login_id = ? and role = 'admin' limit 1",
      [loginId]
    );
    if (!rows.length) return jsonError("관리자 계정이 아닙니다.", 401);
    const admin = rows[0];
    if (String(admin.password || "") !== password) {
      return jsonError("아이디 또는 비밀번호가 올바르지 않습니다.", 401);
    }

    const token = await createSession(context.env, "admin", {
      adminId: admin.id,
      loginId: admin.login_id,
      role: "admin",
    });

    return jsonOk({
      token,
      admin: {
        id: admin.id,
        loginId: admin.login_id,
        name: admin.name,
        email: admin.email,
        role: "admin",
      },
    });
  } catch (error) {
    return jsonError(`관리자 로그인 오류: ${error.message || error}`, 500);
  }
}
