import {
  d1Execute,
  d1Query,
  jsonError,
  jsonOk,
  parseJson,
} from "../_lib/cloudflare_store.js";
import { requireAdminSession } from "./_auth.js";

export async function onRequestPatch(context) {
  try {
    const adminSession = await requireAdminSession(context);
    if (!adminSession) return jsonError("관리자 로그인이 필요합니다.", 401);

    const body = await parseJson(context.request);
    const memberId = String(body.memberId || "").trim();
    const pointBalanceRaw = Number(body.pointBalance);
    const nextPassword = String(body.password || "");
    const passwordChanged = nextPassword.length > 0;

    if (!memberId) return jsonError("회원 ID가 필요합니다.", 400);
    if (!Number.isFinite(pointBalanceRaw) || pointBalanceRaw < 0) {
      return jsonError("포인트는 0 이상의 숫자여야 합니다.", 400);
    }
    if (passwordChanged && nextPassword.length < 4) {
      return jsonError("비밀번호는 4자 이상이어야 합니다.", 400);
    }

    const rows = await d1Query(
      context.env,
      "select id, login_id, role from members where id = ? limit 1",
      [memberId]
    );
    if (!rows.length) return jsonError("회원을 찾을 수 없습니다.", 404);
    const member = rows[0];
    const now = new Date().toISOString();
    const nextPointBalance = Math.round(pointBalanceRaw);

    if (passwordChanged) {
      await d1Execute(
        context.env,
        "update members set point_balance = ?, password = ?, updated_at = ? where id = ?",
        [nextPointBalance, nextPassword, now, memberId]
      );
    } else {
      await d1Execute(
        context.env,
        "update members set point_balance = ?, updated_at = ? where id = ?",
        [nextPointBalance, now, memberId]
      );
    }

    await d1Execute(context.env, "insert into admin_logs (message, created_at) values (?, ?)", [
      `회원 정보 수정: ${member.login_id} (${member.role || "member"}) / 포인트=${nextPointBalance}${passwordChanged ? " / 비밀번호 변경" : ""}`,
      now,
    ]);

    return jsonOk({
      member: {
        id: memberId,
        loginId: member.login_id,
        pointBalance: nextPointBalance,
        passwordChanged,
      },
    });
  } catch (error) {
    return jsonError(`회원 정보 수정 오류: ${error.message || error}`, 500);
  }
}
