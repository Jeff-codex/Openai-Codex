import {
  d1Execute,
  d1Query,
  jsonError,
  jsonOk,
  parseJson,
} from "../_lib/cloudflare_store.js";
import { requireAdminSession } from "./_auth.js";

function parsePrice(value) {
  const n = Number(String(value ?? "").replace(/[^\d.-]/g, ""));
  return Number.isFinite(n) ? Math.max(0, Math.round(n)) : 0;
}

export async function onRequestPost(context) {
  try {
    const adminSession = await requireAdminSession(context);
    if (!adminSession) return jsonError("관리자 로그인이 필요합니다.", 401);

    const body = await parseJson(context.request);
    const name = String(body.name || "").trim();
    const category = String(body.category || "").trim();
    const memberPrice = String(body.memberPrice || "회원전용").trim() || "회원전용";
    const unitPrice = parsePrice(body.unitPrice || memberPrice);

    if (!name || !category) {
      return jsonError("매체명과 카테고리를 입력해 주세요.", 400);
    }

    const id = `media_${crypto.randomUUID()}`;
    const now = new Date().toISOString();
    await d1Execute(
      context.env,
      "insert into media_channels (id, name, category, byline_type, unit_price, member_price_label, channel, description, is_active, created_at, updated_at) values (?, ?, ?, '', ?, ?, '', '', 1, ?, ?)",
      [id, name, category, unitPrice, memberPrice, now, now]
    );
    await d1Execute(context.env, "insert into admin_logs (message, created_at) values (?, ?)", [
      `매체 추가: ${name} (${category})`,
      now,
    ]);

    return jsonOk({
      media: {
        id,
        name,
        category,
        unitPrice,
        memberPrice,
        isActive: true,
      },
    });
  } catch (error) {
    return jsonError(`매체 추가 오류: ${error.message || error}`, 500);
  }
}

export async function onRequestPatch(context) {
  try {
    const adminSession = await requireAdminSession(context);
    if (!adminSession) return jsonError("관리자 로그인이 필요합니다.", 401);

    const body = await parseJson(context.request);
    const mediaId = String(body.mediaId || "").trim();
    if (!mediaId) return jsonError("매체 ID가 필요합니다.", 400);

    const rows = await d1Query(
      context.env,
      "select id, name, is_active from media_channels where id = ? limit 1",
      [mediaId]
    );
    if (!rows.length) return jsonError("매체를 찾을 수 없습니다.", 404);
    const media = rows[0];
    const nextActive = Number(media.is_active || 0) === 1 ? 0 : 1;
    const now = new Date().toISOString();

    await d1Execute(context.env, "update media_channels set is_active = ?, updated_at = ? where id = ?", [
      nextActive,
      now,
      mediaId,
    ]);
    await d1Execute(context.env, "insert into admin_logs (message, created_at) values (?, ?)", [
      `매체 상태 변경: ${media.name} (${nextActive === 1 ? "활성" : "비활성"})`,
      now,
    ]);

    return jsonOk({ mediaId, isActive: nextActive === 1 });
  } catch (error) {
    return jsonError(`매체 상태 변경 오류: ${error.message || error}`, 500);
  }
}
