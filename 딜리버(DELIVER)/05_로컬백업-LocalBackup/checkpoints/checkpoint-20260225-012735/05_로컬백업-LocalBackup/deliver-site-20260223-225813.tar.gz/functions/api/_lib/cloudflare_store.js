const JSON_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
};

function requireD1(env) {
  if (!env.DB || typeof env.DB.prepare !== "function") {
    throw new Error("Missing D1 binding: DB");
  }
  return env.DB;
}

function requireKv(env) {
  if (!env.SESSION_KV || typeof env.SESSION_KV.get !== "function") {
    throw new Error("Missing KV binding: SESSION_KV");
  }
  return env.SESSION_KV;
}

function requireR2(env) {
  if (!env.FILES_BUCKET || typeof env.FILES_BUCKET.put !== "function") {
    throw new Error("Missing R2 binding: FILES_BUCKET");
  }
  return env.FILES_BUCKET;
}

export async function d1Query(env, sql, params = []) {
  const db = requireD1(env);
  const statement = db.prepare(sql).bind(...params);
  const result = await statement.all();
  if (!result.success) {
    throw new Error(`D1 query failed: ${sql}`);
  }
  return result.results || [];
}

export async function d1Execute(env, sql, params = []) {
  const db = requireD1(env);
  const statement = db.prepare(sql).bind(...params);
  const result = await statement.run();
  if (!result.success) {
    throw new Error(`D1 execute failed: ${sql}`);
  }
}

export async function kvPut(env, key, value, ttlSeconds) {
  const kv = requireKv(env);
  if (ttlSeconds && ttlSeconds > 0) {
    await kv.put(key, value, { expirationTtl: Math.round(ttlSeconds) });
    return;
  }
  await kv.put(key, value);
}

export async function kvGet(env, key) {
  const kv = requireKv(env);
  return kv.get(key);
}

export async function kvDelete(env, key) {
  const kv = requireKv(env);
  await kv.delete(key);
}

export function hasR2Binding(env) {
  return Boolean(env?.FILES_BUCKET && typeof env.FILES_BUCKET.put === "function");
}

export async function r2Put(env, key, value, options = undefined) {
  const bucket = requireR2(env);
  return bucket.put(key, value, options);
}

export async function r2Get(env, key, options = undefined) {
  const bucket = requireR2(env);
  return bucket.get(key, options);
}

export async function r2Delete(env, key) {
  const bucket = requireR2(env);
  return bucket.delete(key);
}

function randomToken(prefix) {
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  const b64 = btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
  return `${prefix}_${b64}`;
}

export async function createSession(env, type, payload) {
  const ttl = type === "admin" ? Number(env.ADMIN_SESSION_TTL_SEC || 86400 * 14) : Number(env.MEMBER_SESSION_TTL_SEC || 86400 * 14);
  const token = randomToken(type === "admin" ? "adm" : "mem");
  const sessionValue = JSON.stringify({
    type,
    ...payload,
    issuedAt: new Date().toISOString(),
  });
  await kvPut(env, `session:${token}`, sessionValue, ttl);
  return token;
}

export async function readSession(env, token, expectedType) {
  if (!token) return null;
  const raw = await kvGet(env, `session:${token}`);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    if (expectedType && parsed.type !== expectedType) return null;
    return parsed;
  } catch (error) {
    return null;
  }
}

export async function destroySession(env, token) {
  if (!token) return;
  await kvDelete(env, `session:${token}`);
}

export function getBearerToken(request) {
  const auth = String(request.headers.get("authorization") || "");
  if (auth.toLowerCase().startsWith("bearer ")) {
    return auth.slice(7).trim();
  }
  return String(request.headers.get("x-session-token") || "").trim();
}

export async function parseJson(request) {
  try {
    return await request.json();
  } catch (error) {
    return {};
  }
}

export function jsonOk(data, status = 200) {
  return new Response(JSON.stringify({ ok: true, ...data }), {
    status,
    headers: JSON_HEADERS,
  });
}

export function jsonError(message, status = 400) {
  return new Response(JSON.stringify({ ok: false, message }), {
    status,
    headers: JSON_HEADERS,
  });
}

export function normalizeEmail(value) {
  return String(value || "").trim().toLowerCase();
}

export function normalizeLoginId(value) {
  return String(value || "").trim().toLowerCase();
}

export function nowIso() {
  return new Date().toISOString();
}
