import {
  createSession,
  d1Query,
  jsonError,
  jsonOk,
  normalizeLoginId,
  parseJson,
} from "../_lib/cloudflare_store.js";

export async function onRequestPost(context) {
  try {
    const body = await parseJson(context.request);
    const loginId = normalizeLoginId(body.loginId);
    const password = String(body.password || "");

    if (!loginId || !password) {
      return jsonError("아이디와 비밀번호를 입력해 주세요.", 400);
    }

    const rows = await d1Query(
      context.env,
      "select id, login_id, name, email, company, point_balance, role, password from members where login_id = ? limit 1",
      [loginId]
    );
    if (!rows.length) {
      return jsonError("아이디 또는 비밀번호가 올바르지 않습니다.", 401);
    }
    const member = rows[0];
    if (String(member.password || "") !== password) {
      return jsonError("아이디 또는 비밀번호가 올바르지 않습니다.", 401);
    }

    const token = await createSession(context.env, "member", {
      memberId: member.id,
      loginId: member.login_id,
      email: member.email,
      role: member.role || "member",
    });

    return jsonOk({
      token,
      member: {
        id: member.id,
        loginId: member.login_id,
        name: member.name,
        email: member.email,
        company: member.company,
        pointBalance: Number(member.point_balance || 0),
        role: member.role || "member",
      },
    });
  } catch (error) {
    return jsonError(`로그인 처리 중 오류: ${error.message || error}`, 500);
  }
}
