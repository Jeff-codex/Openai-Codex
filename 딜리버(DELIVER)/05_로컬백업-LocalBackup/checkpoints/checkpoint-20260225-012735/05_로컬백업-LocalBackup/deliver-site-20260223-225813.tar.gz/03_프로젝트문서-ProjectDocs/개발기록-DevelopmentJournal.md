# 딜리버 개발 기록 (Development Journal)

아래 형식으로 단계 완료 시 자동 누적됩니다.

## 기록 샘플
- 단계: 작업 단계명
- 요약: 완료 내용 요약
- 변경 파일:
- `상대경로/파일명`
- 다음 작업: 이어서 할 작업

## 2026-02-23 16:54:02 KST
- 단계: 기록 스크립트 한글 경로 출력 개선
- 요약: 단계 완료 체크포인트 저장
- 변경 파일:
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/랜딩페이지-LandingPage/index.html
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/원격백업가이드-RemoteBackupGuide.md
- 딜리버(DELIVER)/README.md
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/.env.supabase.example
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발원칙-DevelopmentPrinciples.md
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/checkpoint.sh
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/resume_deliver.sh
- 다음 작업: 이어서 개발 진행

## 2026-02-23 16:56:39 KST
- 단계: 미리보기 경로 자동 출력 원칙 반영
- 요약: 단계 완료 체크포인트 저장
- 변경 파일:
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발원칙-DevelopmentPrinciples.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/원격백업가이드-RemoteBackupGuide.md
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/checkpoint.sh
- 딜리버(DELIVER)/README.md
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/preview_paths.sh
- 다음 작업: 이어서 개발 진행

## 2026-02-23 17:07:33 KST
- 단계: Admin MVP 골격 및 Supabase 스키마 추가
- 요약: 단계 완료 체크포인트 저장
- 변경 파일:
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/랜딩페이지-LandingPage/index.html
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발원칙-DevelopmentPrinciples.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/원격백업가이드-RemoteBackupGuide.md
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/checkpoint.sh
- 딜리버(DELIVER)/README.md
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/AdminMVP-운영구성-AdminMVPBlueprint.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/DB스키마-SupabaseSchema.sql
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/preview_paths.sh
- 다음 작업: 이어서 개발 진행

## 2026-02-23 17:12:47 KST
- 단계: Supabase 기초 인프라 및 동기화 스크립트 구축
- 요약: 단계 완료 체크포인트 저장
- 변경 파일:
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/랜딩페이지-LandingPage/index.html
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발원칙-DevelopmentPrinciples.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/원격백업가이드-RemoteBackupGuide.md
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/checkpoint.sh
- 딜리버(DELIVER)/README.md
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/AdminMVP-운영구성-AdminMVPBlueprint.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/DB스키마-SupabaseSchema.sql
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/Supabase연동가이드-SupabaseSetupGuide.md
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/preview_paths.sh
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/supabase_sync_seed.mjs
- 딜리버(DELIVER)/08_데이터베이스-Database/
- 다음 작업: 이어서 개발 진행

## 2026-02-23 17:23:39 KST
- 단계: 딜리버(Deliver) 테이블 URL 및 RLS 마이그레이션 구축
- 요약: 단계 완료 체크포인트 저장
- 변경 파일:
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/랜딩페이지-LandingPage/index.html
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발원칙-DevelopmentPrinciples.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/원격백업가이드-RemoteBackupGuide.md
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/checkpoint.sh
- 딜리버(DELIVER)/README.md
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/AdminMVP-운영구성-AdminMVPBlueprint.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/DB스키마-SupabaseSchema.sql
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/Supabase연동가이드-SupabaseSetupGuide.md
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/preview_paths.sh
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/supabase_sync_seed.mjs
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/supabase_urls.sh
- 딜리버(DELIVER)/08_데이터베이스-Database/
- 다음 작업: 이어서 개발 진행

## 2026-02-23 19:14:03 KST
- 단계: 도메인/인증/Pages 배포 통합 연동 및 운영 경로 표준화
- 요약: 랜딩/관리자 로그인 기능 안정화, 관리자 단일 계정 게이트 적용, Cloudflare DNS(운영/스테이징/개발+MX/TXT/DMARC/CAA) 점검 및 보강, Cloudflare Pages(dilver) 프로젝트 생성 및 정적 배포 완료, 커스텀 도메인 연동 반영
- 변경 파일:
- 딜리버(DELIVER)/index.html
- 딜리버(DELIVER)/README.md
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/랜딩페이지-LandingPage/index.html
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/index.html
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/app.js
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/styles.css
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발원칙-DevelopmentPrinciples.md
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/preview_paths.sh
- 다음 작업: Pages 커스텀 도메인 상태(active) 전환 최종 확인 후 API 실서비스 백엔드 분리 연동

## 2026-02-23 19:40:45 KST
- 단계: 회원전용 주문 대시보드 구축 및 로그인 후 자동 리다이렉트 연동
- 요약: 회원가입/로그인 성공 시 회원전용 페이지로 자동 이동하도록 랜딩 인증 플로우를 연결했고, 엑셀 기반 매체 시드(공통 데이터)를 반영한 회원 주문 대시보드(매체 선택/포인트/주문 상태)를 구현했으며, 관리자 페이지에도 동일 시드 연동을 적용해 주문 상태 동기화가 가능하도록 정리함. Playwright E2E로 회원가입→주문→관리자 상태변경→회원 반영까지 검증 완료.
- 변경 파일:
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/랜딩페이지-LandingPage/index.html
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/index.html
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/styles.css
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/app.js
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/index.html
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/app.js
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/preview_paths.sh
- 딜리버(DELIVER)/index.html
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 다음 작업: Cloudflare Pages 운영 배포 반영 후 실 도메인에서 회원전용 플로우(로그인/주문/상태 동기화) 재검증

## 2026-02-23 19:44:17 KST
- 단계: 단계 완료 보고 원칙 변경(경로 중심 → 체크리스트 중심)
- 요약: 매 단계 완료 시 Windows 접속 경로를 기본 제공하던 원칙을 중지하고, 앞으로는 `완료/미완료 체크리스트`를 기본 보고 형식으로 고정하도록 개발 원칙 및 README 정책을 갱신함.
- 변경 파일:
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발원칙-DevelopmentPrinciples.md
- 딜리버(DELIVER)/README.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 다음 작업: 다음 개발 단계부터 체크리스트 기반 완료 보고 형식 적용

## 2026-02-23 19:54:36 KST
- 단계: 미완료 항목 즉시 실행(운영 배포/실도메인 회귀/Supabase 실연동 점검)
- 요약: Cloudflare Pages `dliver`에 최신 변경을 재배포(배포 URL: `https://141e8d49.dliver.pages.dev`)했고, 운영 도메인 실브라우저 회귀 테스트에서 회원가입→회원전용 리다이렉트→주문등록→관리자 상태변경→회원 상태반영까지 검증 완료. 또한 admin 서브도메인 접속 시 메인 도메인 관리자 경로로 라우팅되도록 수정해 LocalStorage 분리 이슈를 임시 안정화함. Supabase 실연동은 원격 스키마 미적용(`media_channels` 테이블 부재, PGRST205)으로 차단되어 SQL 마이그레이션 선적용이 필요함.
- 변경 파일:
- 딜리버(DELIVER)/index.html
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 다음 작업: Supabase SQL Editor에서 `001_init_supabase_schema.sql` + `002_create_deliver_table_with_rls.sql` 실행 후 `supabase_sync_seed.mjs` 재실행하여 실연동 마무리

## 2026-02-23 20:44:44 KST
- 단계: Cloudflare API 기반 인프라 직접 구축(D1/KV)
- 요약: 제공받은 Cloudflare API 토큰으로 D1(`dliver-prod-db`)과 KV(`dliver-session-kv-prod`)를 직접 생성했고, D1 전용 스키마 마이그레이션(`003_init_d1_schema.sql`) 및 엑셀 기반 매체 121건 시드를 원격 반영 완료. 기본 계정(admin/test) 시드 확인까지 완료. R2는 계정 수준 미활성(`10042`)로 API 생성 불가 상태를 재확인.
- 변경 파일:
- 딜리버(DELIVER)/08_데이터베이스-Database/01_마이그레이션-Migrations/003_init_d1_schema.sql
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 다음 작업: R2 대시보드 온보딩 완료 후 버킷 생성 및 Pages Functions에 D1/KV/R2 바인딩 연결

## 2026-02-23 21:12:00 KST
- 단계: Cloudflare 전용 고정값 전환 및 R2 활성화 재검토
- 요약: Supabase 관련 실행 파일(.env 예시/동기화 스크립트/마이그레이션/가이드)을 프로젝트 운영 경로에서 제거하고, DB 백업 자동화를 `cloudflare_d1_snapshot.mjs` 기반으로 교체해 Cloudflare D1 전용으로 정리함. R2 API 재검토 결과 토큰은 active이나 계정 API 응답이 계속 `10042`(Dashboard R2 온보딩 미완료)로 반환되어 버킷 생성은 보류됨. 추가로 현재 토큰은 Pages 프로젝트 읽기/배포 권한이 없어 wrangler 배포는 인증 오류(`10000`)로 차단됨.
- 변경 파일:
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/cloudflare_d1_snapshot.mjs
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/database_backup_all.sh
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/.env.cloudflare.example
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/Cloudflare연동가이드-CloudflareSetupGuide.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발원칙-DevelopmentPrinciples.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/.env.supabase.example (삭제)
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/DB스키마-SupabaseSchema.sql (삭제)
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/Supabase연동가이드-SupabaseSetupGuide.md (삭제)
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/supabase_backup_all.mjs (삭제)
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/supabase_sync_seed.mjs (삭제)
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/supabase_urls.sh (삭제)
- 딜리버(DELIVER)/08_데이터베이스-Database/01_마이그레이션-Migrations/001_init_supabase_schema.sql (삭제)
- 딜리버(DELIVER)/08_데이터베이스-Database/01_마이그레이션-Migrations/002_create_deliver_table_with_rls.sql (삭제)
- 다음 작업: R2 Dashboard 온보딩 최종 완료 확인 후 버킷 생성 API 재시도, Pages 배포 권한 포함 토큰 발급 후 최신 코드 재배포 및 실도메인 검증

## 2026-02-23 21:16:00 KST
- 단계: R2 활성화 완료 반영 및 버킷 생성/연동 재시도
- 요약: Cloudflare R2 활성화 이후 API 재검증에서 버킷 목록 조회가 정상화되었고, `dliver-prod-files` 버킷 생성을 성공 처리함. Functions 공통 유틸에 R2 바인딩 헬퍼(`FILES_BUCKET`)를 추가하고 `/api/health` 응답에 `r2Ready`를 노출해 배포 후 연동 상태를 즉시 점검 가능하도록 확장함. 다만 현재 토큰은 Pages 권한이 부족해 프로젝트 조회/패치가 `10000 Authentication error`로 차단되어 R2 바인딩의 원격 연결 및 재배포는 보류됨.
- 변경 파일:
- 딜리버(DELIVER)/functions/api/_lib/cloudflare_store.js
- 딜리버(DELIVER)/functions/api/health.js
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/Cloudflare연동가이드-CloudflareSetupGuide.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 다음 작업: Pages 권한 포함 토큰으로 `dliver` 프로젝트에 `FILES_BUCKET` 바인딩 적용 후 최신 코드 재배포 및 `/api/health` 실도메인 검증

## 2026-02-23 21:23:00 KST
- 단계: R2 운영 검증(버킷 생성 + 오브젝트 스모크 테스트)
- 요약: R2 전용 토큰으로 `dliver-prod-files` 버킷 생성을 완료했고, `wrangler r2 object`를 통해 업로드→다운로드→무결성 비교→삭제까지 원격 스모크 테스트를 통과해 R2 실사용 가능 상태를 확인함. 현재 전달 토큰은 R2 권한만 보유하여 Pages 프로젝트 조회/패치는 `10000`으로 차단되어, `FILES_BUCKET` 바인딩 적용 및 재배포는 Pages 권한 토큰이 추가로 필요함.
- 변경 파일:
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 다음 작업: Pages Edit 권한 토큰 발급 후 프로젝트 `dliver`에 R2 바인딩(`FILES_BUCKET -> dliver-prod-files`) 적용 및 최신 배포

## 2026-02-23 21:28:00 KST
- 단계: Pages 권한 토큰 반영 후 R2 바인딩/재배포/운영 검증
- 요약: 새 Pages 권한 토큰(`bltV0...`)으로 프로젝트 `dliver` 조회 및 패치 권한을 확인했고, preview/production 모두에 `FILES_BUCKET -> dliver-prod-files` R2 바인딩을 적용했다. 이후 최신 코드를 `https://070a20be.dliver.pages.dev`로 재배포했고, 운영 도메인 `https://dliver.co.kr/api/health`에서 `r2Ready: true`, `mediaCount: 121`을 확인했다. 추가로 실운영 API 스모크 테스트(회원가입→로그인→주문→조회→로그아웃, 관리자 로그인→bootstrap→로그아웃)까지 정상 완료.
- 변경 파일:
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 다음 작업: 보안 정리(CF_API_TOKEN 환경변수 제거/토큰 회전) 및 첨부파일 업로드 API(R2) 기능 확장

## 2026-02-23 21:33:00 KST
- 단계: 로그인/회원가입 전체 디버깅 체크 및 안정화 패치
- 요약: 운영 도메인 기준 API/도메인/관리자 서브도메인 전수 점검에서 로그인·회원가입·주문 흐름은 정상 재현됨. 프론트 스크립트에서 DOM 요소 누락 시 전체 인증 로직이 중단되지 않도록 방어 처리(optional chaining + null-safe UI 갱신)를 추가했고, 재현/회귀를 자동화하기 위해 `auth_debug_check.sh`를 신규 도입함. 최신 배포(`https://565d3cd2.dliver.pages.dev`) 후 운영 도메인에서 health(`r2Ready=true`) 및 auth E2E 스모크 테스트를 재실행하여 정상 확인.
- 변경 파일:
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/랜딩페이지-LandingPage/index.html
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/auth_debug_check.sh
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 다음 작업: 사용자 브라우저에서 동일 증상 재발 시 콘솔 에러/네트워크 응답 캡처 기반 원인 고정

## 2026-02-23 21:39:00 KST
- 단계: 로그인 후 회원전용페이지 랜딩 튕김 이슈 안정화
- 요약: 회원전용 페이지 초기화 로직에서 `/api/media` 또는 `/api/orders` 일시 실패까지 인증 실패로 처리해 토큰 삭제 후 랜딩으로 강제 이동하던 문제를 수정함. 이제 랜딩 이동은 `401` 인증 실패일 때만 수행되며, 기타 API 오류는 세션 유지 상태에서 재동기화로 처리된다. 추가로 로그인 이동 경로에 hash 토큰 fallback(`t=`)과 sessionStorage 보조 저장을 적용해 리다이렉트 안정성을 강화함. 최신 배포(`https://5dd9cfab.dliver.pages.dev`) 후 운영 도메인 auth 스모크 테스트 통과 확인.
- 변경 파일:
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/랜딩페이지-LandingPage/index.html
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/app.js
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/auth_debug_check.sh
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 다음 작업: 사용자 실브라우저 재현 로그(콘솔/네트워크) 수집 시 추가 엣지케이스 보정

## 2026-02-23 21:45:00 KST
- 단계: 로그인 후 랜딩 튕김 최종 안정화(캐시 강제 무효화 포함)
- 요약: 회원전용 페이지 튕김 이슈의 재발 원인을 정적 JS 캐시(max-age=14400) 재사용 가능성까지 포함해 보강함. 회원전용 페이지 이동 경로를 `index.html?v=20260223r3`로 고정하고, 회원전용 페이지 스크립트 로딩도 `app.js?v=20260223r3`/`media_seed.js?v=20260223r3`로 변경해 구버전 캐시를 강제로 우회하도록 조치. 운영 배포(`https://0e889122.dliver.pages.dev`) 후 도메인 반영 및 auth 회귀 테스트 정상 확인.
- 변경 파일:
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/랜딩페이지-LandingPage/index.html
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/index.html
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/app.js
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 다음 작업: 사용자 체감 기준 로그인 재시도 결과 확인 및 필요 시 관리자 페이지에도 동일 캐시 버전 정책 확대

## 2026-02-23 21:52:00 KST
- 단계: 회원 주문 원고파일첨부 + 관리자 열람/저장 기능 구축
- 요약: 회원전용 주문 등록 폼에 `원고파일첨부` 버튼/입력을 추가하고, 주문 API를 multipart 업로드 지원으로 확장해 R2(`dliver-prod-files`)에 원고 파일 저장 및 D1 메타데이터(`order_attachments`) 기록을 구현함. 관리자 주문 목록에 첨부파일 열을 추가해 `열람`/`저장` 버튼을 제공하고, 관리자 인증 기반 파일 스트리밍 API(`/api/admin/attachment`)를 신규 구현함. 운영 배포(`https://e0d41fc4.dliver.pages.dev`) 후 E2E 검증(회원 업로드→관리자 bootstrap 반영→다운로드 파일 무결성 비교) 통과.
- 변경 파일:
- 딜리버(DELIVER)/functions/api/_lib/order_attachment_store.js
- 딜리버(DELIVER)/functions/api/orders/index.js
- 딜리버(DELIVER)/functions/api/admin/bootstrap.js
- 딜리버(DELIVER)/functions/api/admin/attachment.js
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/index.html
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/styles.css
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/app.js
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/index.html
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/styles.css
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/app.js
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/랜딩페이지-LandingPage/index.html
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/Cloudflare연동가이드-CloudflareSetupGuide.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 다음 작업: 관리자 주문 상세(첨부 다건/삭제/교체) 기능 확장 여부 결정

## 2026-02-23 21:58:00 KST
- 단계: 포인트 정책 변경(회원가입 0포인트) + 주문 사용포인트 자동단가 고정
- 요약: 회원가입 기본 지급 포인트를 5,000,000에서 0으로 변경하고(`signup` API 반영), 회원전용 주문 등록 화면에서 사용포인트를 매체 선택 단가로 자동 입력/읽기전용 처리함. 서버에서도 주문 `budget` 값을 클라이언트 입력 대신 선택 매체 `unit_price`로 강제해 우회 입력을 차단함. 운영 배포(`https://5a090a70.dliver.pages.dev`) 후 실검증에서 신규 회원가입 `pointBalance:0` 확인, 주문 API 강제단가 적용(`budget=1` 전송해도 `unit_price` 반영) 확인.
- 변경 파일:
- 딜리버(DELIVER)/functions/api/auth/signup.js
- 딜리버(DELIVER)/functions/api/orders/index.js
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/index.html
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/styles.css
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/app.js
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/랜딩페이지-LandingPage/index.html
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/auth_debug_check.sh
- 딜리버(DELIVER)/08_데이터베이스-Database/01_마이그레이션-Migrations/003_init_d1_schema.sql
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 다음 작업: 포인트 충전/차감 관리 정책(관리자 충전 UI) 확정

## 2026-02-23 22:04:00 KST
- 단계: 관리자 주문관리 표에 회원아이디 컬럼 추가
- 요약: 관리자페이지 주문관리 테이블에서 `주문명` 오른쪽에 `회원아이디` 컬럼을 추가하고, 주문 렌더링 시 `memberLoginId`를 표시하도록 수정함. 빈 데이터 행 `colspan`도 신규 컬럼 수에 맞춰 조정했고, 캐시 반영을 위해 관리자 스크립트 버전을 `v=20260223r5`로 갱신함. 운영 배포(`https://06fbe591.dliver.pages.dev`) 후 `admin.dliver.co.kr`에서 컬럼 반영 확인 완료.
- 변경 파일:
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/index.html
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/app.js
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 다음 작업: 주문관리 표 항목(회원아이디/이메일 기준 필터링) 확장 여부 결정

## 2026-02-23 22:05:00 KST
- 단계: 관리자 주문관리 10건 단위 페이지네이션 적용
- 요약: 관리자 주문관리 테이블이 수직 무한 노출되지 않도록 페이지당 10건 고정(`ORDERS_PAGE_SIZE=10`)으로 변경하고, 10건 초과 시 페이지 버튼(이전/1..N/다음)으로 이동하도록 구현함. 주문 렌더링은 현재 페이지 슬라이스만 표시하며, 빈 상태 `colspan` 및 캐시 버전(`v=20260223r6`)도 함께 갱신. 운영 배포(`https://25e76ca1.dliver.pages.dev`) 후 반영 확인.
- 변경 파일:
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/index.html
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/app.js
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/styles.css
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 다음 작업: 주문관리 페이지네이션에 페이지당 건수 옵션(10/20/50) 추가 여부 결정

## 2026-02-23 22:09:00 KST
- 단계: 회원전용페이지 매체선택 UI 그룹화 + 클릭 스크롤 선택 구조 개선
- 요약: 매체 선택 목록의 수직 과다 길이 문제를 해결하기 위해 매체를 카테고리별 그룹으로 묶고, 상단 그룹 버튼 클릭 시 아래 그룹 목록 컨테이너로 스크롤 이동되도록 개편함. 기존 테이블 리스트를 그룹 카드 목록(`media-group-nav`/`media-group-list`)으로 대체하고, 검색/선택/선택상태 하이라이트/선택단가 자동동기화는 유지함. 캐시 버전을 `v=20260223r6`으로 갱신해 즉시 반영되도록 처리하고 운영 배포(`https://6877b1b6.dliver.pages.dev`) 완료.
- 변경 파일:
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/index.html
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/styles.css
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/app.js
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/랜딩페이지-LandingPage/index.html
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 다음 작업: 그룹 펼침(접기/펼치기) 또는 즐겨찾기 매체 고정 기능 추가 여부 결정

## 2026-02-23 22:58:12 KST
- 단계: 미완료 체크리스트 자동정리 점검
- 요약: 단계 완료 체크포인트 저장
- 변경 파일:
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/.env.supabase.example
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/랜딩페이지-LandingPage/index.html
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발기록-DevelopmentJournal.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/개발원칙-DevelopmentPrinciples.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/원격백업가이드-RemoteBackupGuide.md
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/checkpoint.sh
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/resume_deliver.sh
- 딜리버(DELIVER)/README.md
- 딜리버(DELIVER)/index.html
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/.env.cloudflare.example
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/공통데이터-SharedData/
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/관리자페이지-AdminPage/
- 딜리버(DELIVER)/01_서비스코드-ServiceCode/회원전용페이지-MemberPortal/
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/AdminMVP-운영구성-AdminMVPBlueprint.md
- 딜리버(DELIVER)/03_프로젝트문서-ProjectDocs/Cloudflare연동가이드-CloudflareSetupGuide.md
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/auth_debug_check.sh
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/cloudflare_d1_snapshot.mjs
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/database_backup_all.sh
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/optimize_storage.sh
- 딜리버(DELIVER)/07_자동화스크립트-AutomationScripts/preview_paths.sh
- 딜리버(DELIVER)/08_데이터베이스-Database/
- 딜리버(DELIVER)/functions/
- 다음 작업: 이어서 개발 진행
