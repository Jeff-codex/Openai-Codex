-- 딜리버 Cloudflare D1(SQLite) 초기 스키마
-- 적용 대상: D1 database (dliver-prod-db)

pragma foreign_keys = on;

create table if not exists members (
  id text primary key,
  login_id text not null unique,
  name text not null,
  email text not null unique,
  company text,
  password text not null,
  point_balance integer not null default 0,
  role text not null default 'member',
  created_at text not null default (datetime('now')),
  updated_at text not null default (datetime('now'))
);

create table if not exists media_channels (
  id text primary key,
  name text not null unique,
  category text not null,
  byline_type text,
  unit_price integer not null default 0,
  member_price_label text not null default '회원전용',
  channel text,
  description text,
  is_active integer not null default 1,
  created_at text not null default (datetime('now')),
  updated_at text not null default (datetime('now'))
);

create table if not exists orders (
  id text primary key,
  member_id text not null,
  member_login_id text,
  member_name text,
  email text,
  title text not null,
  media_id text,
  media_name text,
  budget integer not null default 0,
  status text not null default 'received',
  request_note text,
  created_at text not null default (datetime('now')),
  updated_at text not null default (datetime('now')),
  foreign key(member_id) references members(id) on delete cascade
);

create table if not exists order_status_logs (
  id integer primary key autoincrement,
  order_id text not null,
  from_status text,
  to_status text not null,
  changed_by text,
  note text,
  changed_at text not null default (datetime('now')),
  foreign key(order_id) references orders(id) on delete cascade,
  foreign key(changed_by) references members(id) on delete set null
);

create table if not exists admin_logs (
  id integer primary key autoincrement,
  message text not null,
  created_at text not null default (datetime('now'))
);

create index if not exists idx_members_login_id on members(login_id);
create index if not exists idx_members_email on members(email);
create index if not exists idx_media_channels_active on media_channels(is_active);
create index if not exists idx_orders_member_id on orders(member_id);
create index if not exists idx_orders_status on orders(status);
create index if not exists idx_orders_created_at on orders(created_at);
create index if not exists idx_order_logs_order_id on order_status_logs(order_id);

insert or ignore into members (
  id,
  login_id,
  name,
  email,
  company,
  password,
  point_balance,
  role
) values (
  'admin_fixed_account',
  'admin',
  '관리자',
  'admin@dliver.local',
  'DLIVER',
  'admin1234',
  0,
  'admin'
);

insert or ignore into members (
  id,
  login_id,
  name,
  email,
  company,
  password,
  point_balance,
  role
) values (
  'member_temp_test',
  'test',
  '테스트계정',
  'test@deliver.local',
  '임시계정',
  '1234',
  0,
  'member'
);
