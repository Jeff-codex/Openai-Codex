const KEYS = {
  members: "deliver_members_v1",
  currentMember: "deliver_current_member_v1",
  orders: "deliver_orders_v1",
  media: "deliver_media_v1",
  logs: "deliver_admin_logs_v1",
};

const ORDER_STATUS = [
  { value: "received", label: "접수" },
  { value: "reviewing", label: "검수중" },
  { value: "queued", label: "송출대기" },
  { value: "published", label: "송출완료" },
  { value: "rejected", label: "반려" },
];

const state = {
  members: [],
  orders: [],
  media: [],
  logs: [],
  memberFilter: "",
};

function readJson(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (error) {
    return fallback;
  }
}

function writeJson(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function uid(prefix) {
  return `${prefix}_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
}

function getStatusLabel(statusValue) {
  const found = ORDER_STATUS.find((status) => status.value === statusValue);
  return found ? found.label : statusValue;
}

function formatDate(iso) {
  try {
    return new Date(iso).toLocaleString("ko-KR");
  } catch (error) {
    return iso;
  }
}

function addLog(message) {
  state.logs.unshift({ id: uid("log"), message, createdAt: new Date().toISOString() });
  state.logs = state.logs.slice(0, 200);
  writeJson(KEYS.logs, state.logs);
}

function saveState() {
  writeJson(KEYS.orders, state.orders);
  writeJson(KEYS.media, state.media);
}

function initData() {
  state.members = readJson(KEYS.members, []);
  state.orders = readJson(KEYS.orders, []);
  state.media = readJson(KEYS.media, []);
  state.logs = readJson(KEYS.logs, []);

  if (!state.media.length) {
    state.media = [
      { id: uid("media"), name: "경제/비즈니스", category: "경제", memberPrice: "회원전용", isActive: true },
      { id: uid("media"), name: "IT/테크", category: "IT", memberPrice: "회원전용", isActive: true },
      { id: uid("media"), name: "라이프/컬처", category: "라이프", memberPrice: "회원전용", isActive: true },
      { id: uid("media"), name: "종합 포털 제휴", category: "포털", memberPrice: "회원전용", isActive: true },
    ];
    writeJson(KEYS.media, state.media);
    addLog("기본 매체 데이터가 초기화되었습니다.");
  }
}

function renderDashboard() {
  const pending = state.orders.filter((order) => order.status !== "published" && order.status !== "rejected").length;
  const activeMedia = state.media.filter((media) => media.isActive).length;

  document.getElementById("stat-members").textContent = String(state.members.length);
  document.getElementById("stat-orders").textContent = String(state.orders.length);
  document.getElementById("stat-pending").textContent = String(pending);
  document.getElementById("stat-media").textContent = String(activeMedia);
}

function renderMembers() {
  const tbody = document.getElementById("members-body");
  const query = state.memberFilter.trim().toLowerCase();
  const filtered = state.members.filter((member) => {
    if (!query) return true;
    return (
      String(member.name || "").toLowerCase().includes(query) ||
      String(member.email || "").toLowerCase().includes(query)
    );
  });

  if (!filtered.length) {
    tbody.innerHTML = `<tr><td colspan="4">회원 데이터가 없습니다.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered
    .map(
      (member) => `
      <tr>
        <td>${formatDate(member.createdAt || new Date().toISOString())}</td>
        <td>${member.name || "-"}</td>
        <td>${member.email || "-"}</td>
        <td>${member.company || "-"}</td>
      </tr>`
    )
    .join("");
}

function renderOrderMediaSelect() {
  const select = document.getElementById("order-media-select");
  const activeMedia = state.media.filter((media) => media.isActive);

  if (!activeMedia.length) {
    select.innerHTML = `<option value="">활성 매체 없음</option>`;
    return;
  }

  select.innerHTML = activeMedia
    .map((media) => `<option value="${media.id}">${media.name} (${media.category})</option>`)
    .join("");
}

function renderOrders() {
  const tbody = document.getElementById("orders-body");
  const mediaMap = new Map(state.media.map((media) => [media.id, media]));

  if (!state.orders.length) {
    tbody.innerHTML = `<tr><td colspan="6">등록된 주문이 없습니다.</td></tr>`;
    return;
  }

  tbody.innerHTML = state.orders
    .map((order) => {
      const media = mediaMap.get(order.mediaId);
      const statusOptions = ORDER_STATUS.map(
        (status) =>
          `<option value="${status.value}" ${order.status === status.value ? "selected" : ""}>${status.label}</option>`
      ).join("");

      return `
      <tr>
        <td>${formatDate(order.createdAt)}</td>
        <td>${order.title}</td>
        <td>${order.email || "비회원/미매핑"}</td>
        <td>${media ? media.name : "-"}</td>
        <td>${Number(order.budget).toLocaleString("ko-KR")}원</td>
        <td>
          <select data-order-status data-order-id="${order.id}">
            ${statusOptions}
          </select>
        </td>
      </tr>`;
    })
    .join("");
}

function renderMedia() {
  const tbody = document.getElementById("media-body");

  if (!state.media.length) {
    tbody.innerHTML = `<tr><td colspan="5">매체 데이터가 없습니다.</td></tr>`;
    return;
  }

  tbody.innerHTML = state.media
    .map(
      (media) => `
      <tr>
        <td>${media.name}</td>
        <td>${media.category}</td>
        <td>${media.memberPrice || "회원전용"}</td>
        <td>${media.isActive ? "활성" : "비활성"}</td>
        <td>
          <button class="btn btn-light" data-toggle-media="${media.id}">
            ${media.isActive ? "비활성화" : "활성화"}
          </button>
        </td>
      </tr>`
    )
    .join("");
}

function renderLogs() {
  const list = document.getElementById("log-list");

  if (!state.logs.length) {
    list.innerHTML = `<li>운영 로그가 없습니다.</li>`;
    return;
  }

  list.innerHTML = state.logs
    .slice(0, 80)
    .map(
      (log) => `
      <li>
        <div>${log.message}</div>
        <div class="log-time">${formatDate(log.createdAt)}</div>
      </li>`
    )
    .join("");
}

function renderAll() {
  renderDashboard();
  renderMembers();
  renderOrderMediaSelect();
  renderOrders();
  renderMedia();
  renderLogs();
}

function switchPanel(panelKey) {
  document.querySelectorAll(".side-btn").forEach((button) => {
    button.classList.toggle("active", button.dataset.panel === panelKey);
  });

  document.querySelectorAll(".panel").forEach((panel) => {
    panel.classList.toggle("hidden", panel.id !== `panel-${panelKey}`);
  });
}

function bindPanelTabs() {
  document.querySelectorAll(".side-btn").forEach((button) => {
    button.addEventListener("click", () => {
      switchPanel(button.dataset.panel);
    });
  });
}

function bindMemberSearch() {
  const input = document.getElementById("member-search");
  input.addEventListener("input", () => {
    state.memberFilter = input.value;
    renderMembers();
  });
}

function bindOrderForm() {
  const form = document.getElementById("order-form");
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const formData = new FormData(form);

    const email = String(formData.get("email") || "").trim().toLowerCase();
    const title = String(formData.get("title") || "").trim();
    const mediaId = String(formData.get("mediaId") || "").trim();
    const budget = Number(formData.get("budget") || 0);

    if (!title || !mediaId || budget <= 0) {
      window.alert("주문명, 매체, 예산을 올바르게 입력해 주세요.");
      return;
    }

    state.orders.unshift({
      id: uid("order"),
      email,
      title,
      mediaId,
      budget,
      status: "received",
      createdAt: new Date().toISOString(),
    });

    saveState();
    addLog(`주문 등록: ${title} (${email || "미지정"})`);
    renderAll();
    form.reset();
    renderOrderMediaSelect();
  });
}

function bindMediaForm() {
  const form = document.getElementById("media-form");
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const formData = new FormData(form);

    const name = String(formData.get("name") || "").trim();
    const category = String(formData.get("category") || "").trim();
    const memberPrice = String(formData.get("memberPrice") || "회원전용").trim() || "회원전용";

    if (!name || !category) {
      window.alert("매체명과 카테고리를 입력해 주세요.");
      return;
    }

    state.media.unshift({
      id: uid("media"),
      name,
      category,
      memberPrice,
      isActive: true,
    });

    saveState();
    addLog(`매체 추가: ${name} (${category})`);
    renderAll();
    form.reset();
  });
}

function bindTableActions() {
  document.addEventListener("change", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLSelectElement)) return;

    if (target.hasAttribute("data-order-status")) {
      const orderId = target.getAttribute("data-order-id");
      const order = state.orders.find((item) => item.id === orderId);
      if (!order) return;

      const before = order.status;
      const after = target.value;
      order.status = after;
      saveState();
      addLog(`주문 상태 변경: ${order.title} (${getStatusLabel(before)} -> ${getStatusLabel(after)})`);
      renderAll();
    }
  });

  document.addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;

    const mediaId = target.getAttribute("data-toggle-media");
    if (!mediaId) return;

    const media = state.media.find((item) => item.id === mediaId);
    if (!media) return;

    media.isActive = !media.isActive;
    saveState();
    addLog(`매체 상태 변경: ${media.name} (${media.isActive ? "활성" : "비활성"})`);
    renderAll();
  });
}

function initModeText() {
  const mode = document.getElementById("data-mode");
  mode.textContent = "데이터 모드: LocalStorage (Supabase 연결 대기)";
}

function init() {
  initModeText();
  initData();
  bindPanelTabs();
  bindMemberSearch();
  bindOrderForm();
  bindMediaForm();
  bindTableActions();
  renderAll();
  switchPanel("dashboard");
}

init();
