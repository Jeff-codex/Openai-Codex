# Supabase 연동 가이드 (딜리버)

## 1) 최상위 폴더 확인
- 프로젝트 최상위 폴더는 `딜리버(DELIVER)`로 고정.

## 2) 스키마 반영
- Supabase SQL Editor에서 실행 파일:
- `08_데이터베이스-Database/01_마이그레이션-Migrations/001_init_supabase_schema.sql`

## 3) 환경변수 입력
- 파일: `01_서비스코드-ServiceCode/.env.supabase`
- 최소 입력값:
  - `SUPABASE_URL`
  - `SUPABASE_SERVICE_ROLE_KEY`

## 4) 현재 데이터 즉시 동기화
- 시드 데이터 파일:
  - `08_데이터베이스-Database/02_시드데이터-SeedData/media_channels.json`
- 실행:
```bash
cd /mnt/c/Users/gusru/code/Openai-Codex/딜리버\(DELIVER\)
./07_자동화스크립트-AutomationScripts/supabase_sync_seed.mjs
```

## 5) 동기화 로그 확인
- 폴더: `08_데이터베이스-Database/03_동기화로그-SyncLogs`

## 6) 관리자 권한 부여 (1회)
- SQL Editor에서 이메일 치환 후 실행:
```sql
insert into public.profiles (id, name, email, role)
select id, 'Admin', email, 'admin'
from auth.users
where email = 'your-email@example.com'
on conflict (id) do update
set role = 'admin';
```
