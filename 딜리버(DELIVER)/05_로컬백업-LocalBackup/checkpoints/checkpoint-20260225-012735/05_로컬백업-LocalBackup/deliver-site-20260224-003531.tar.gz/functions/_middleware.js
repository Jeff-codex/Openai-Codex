const API_PREFIX = "/api/";
const SAFE_METHODS = new Set(["GET", "HEAD", "OPTIONS"]);
const ORIGIN_GUARD_METHODS = new Set(["POST", "PUT", "PATCH", "DELETE"]);
const CSRF_COOKIE_NAME = "deliver_csrf";
const CSRF_EXEMPT_PATHS = new Set([
  "/api/auth/login",
  "/api/auth/signup",
  "/api/admin/login",
  "/api/health",
]);

const RATE_LIMIT_RULES = [
  { prefix: "/api/admin/login", key: "admin-login", limit: 8, windowSec: 60 },
  { prefix: "/api/auth/login", key: "member-login", limit: 10, windowSec: 60 },
  { prefix: "/api/auth/signup", key: "member-signup", limit: 6, windowSec: 300 },
  { prefix: "/api/", key: "api-general", limit: 240, windowSec: 60 },
];

const DEFAULT_ALLOWED_ORIGINS = [
  "https://dliver.co.kr",
  "https://admin.dliver.co.kr",
  "https://staging.dliver.co.kr",
  "https://dev.dliver.co.kr",
];

function randomToken(size = 18) {
  const bytes = new Uint8Array(size);
  crypto.getRandomValues(bytes);
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function parseCookies(request) {
  const raw = String(request.headers.get("cookie") || "");
  const map = {};
  raw.split(";").forEach((part) => {
    const idx = part.indexOf("=");
    if (idx <= 0) return;
    const key = part.slice(0, idx).trim();
    const value = part.slice(idx + 1).trim();
    if (!key) return;
    map[key] = value;
  });
  return map;
}

function serializeCookie(name, value, options = {}) {
  const parts = [`${name}=${value}`];
  parts.push(`Path=${options.path || "/"}`);
  if (options.maxAge !== undefined) parts.push(`Max-Age=${Math.max(0, Math.round(Number(options.maxAge) || 0))}`);
  if (options.sameSite) parts.push(`SameSite=${options.sameSite}`);
  if (options.httpOnly) parts.push("HttpOnly");
  if (options.secure) parts.push("Secure");
  return parts.join("; ");
}

function getClientIp(request) {
  const direct = String(request.headers.get("cf-connecting-ip") || "").trim();
  if (direct) return direct;
  const forwarded = String(request.headers.get("x-forwarded-for") || "").trim();
  if (!forwarded) return "unknown";
  return String(forwarded.split(",")[0] || "unknown").trim() || "unknown";
}

function getPathname(request) {
  const url = new URL(request.url);
  return url.pathname;
}

function parseAllowedOrigins(env, request) {
  const set = new Set(DEFAULT_ALLOWED_ORIGINS);
  const fromEnv = String(env.CORS_ALLOW_ORIGINS || "")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
  fromEnv.forEach((origin) => set.add(origin));

  // Allow current preview origin for *.pages.dev deployments.
  try {
    const current = new URL(request.url);
    if (current.hostname.endsWith(".pages.dev")) {
      set.add(current.origin);
    }
  } catch (error) {
  }

  return set;
}

function applySecurityHeaders(headers, requestId) {
  headers.set("x-request-id", requestId);
  headers.set("x-content-type-options", "nosniff");
  headers.set("x-frame-options", "DENY");
  headers.set("referrer-policy", "strict-origin-when-cross-origin");
  headers.set("permissions-policy", "geolocation=(), microphone=(), camera=(), payment=()");
  headers.set("cross-origin-opener-policy", "same-origin");
  headers.set("cross-origin-resource-policy", "same-site");
  headers.set("strict-transport-security", "max-age=31536000; includeSubDomains; preload");
}

function applyCorsHeaders(headers, origin, allowedOrigins) {
  if (!origin) return;
  if (!allowedOrigins.has(origin)) return;
  headers.set("access-control-allow-origin", origin);
  headers.set("access-control-allow-credentials", "true");
  headers.append("vary", "Origin");
}

async function enforceRateLimit(env, key, limit, windowSec, ip) {
  if (!env?.SESSION_KV || typeof env.SESSION_KV.get !== "function") {
    return { ok: true, current: 0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
  const rateKey = `rate:${key}:${ip}:${bucket}`;
  const  0 };
  }
  const bucket = Math.floor(Date.now() / (windowSec * 1000));
