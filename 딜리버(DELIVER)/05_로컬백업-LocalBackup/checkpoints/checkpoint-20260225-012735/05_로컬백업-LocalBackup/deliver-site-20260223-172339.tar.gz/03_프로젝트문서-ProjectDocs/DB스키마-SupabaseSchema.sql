-- 딜리버 Supabase 기본 스키마 (회원/주문/매체/운영로그)
-- 적용 순서: SQL Editor에서 전체 실행

create extension if not exists pgcrypto;

create type public.user_role as enum ('member', 'admin');
create type public.order_status as enum ('received', 'reviewing', 'queued', 'published', 'rejected');

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  email text not null unique,
  company text,
  phone text,
  role public.user_role not null default 'member',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.media_channels (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  category text not null,
  member_price_label text not null default '회원전용',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  member_id uuid references public.profiles(id) on delete set null,
  title text not null,
  company text,
  status public.order_status not null default 'received',
  budget numeric(12,2) not null default 0,
  requested_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  media_channel_id uuid not null references public.media_channels(id),
  quantity integer not null default 1 check (quantity > 0),
  unit_price numeric(12,2) not null default 0,
  subtotal numeric(12,2) not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.order_status_logs (
  id bigserial primary key,
  order_id uuid not null references public.orders(id) on delete cascade,
  from_status public.order_status,
  to_status public.order_status not null,
  changed_by uuid references public.profiles(id) on delete set null,
  note text,
  changed_at timestamptz not null default now()
);

create index if not exists idx_orders_member_id on public.orders(member_id);
create index if not exists idx_orders_status on public.orders(status);
create index if not exists idx_order_items_order_id on public.order_items(order_id);
create index if not exists idx_order_logs_order_id on public.order_status_logs(order_id);

create or replace function public.touch_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_profiles_touch_updated_at on public.profiles;
create trigger trg_profiles_touch_updated_at
before update on public.profiles
for each row execute function public.touch_updated_at();

drop trigger if exists trg_media_channels_touch_updated_at on public.media_channels;
create trigger trg_media_channels_touch_updated_at
before update on public.media_channels
for each row execute function public.touch_updated_at();

drop trigger if exists trg_orders_touch_updated_at on public.orders;
create trigger trg_orders_touch_updated_at
before update on public.orders
for each row execute function public.touch_updated_at();

create or replace function public.is_admin(uid uuid)
returns boolean
language sql
stable
as $$
  select exists (
    select 1
    from public.profiles p
    where p.id = uid
      and p.role = 'admin'
  );
$$;

alter table public.profiles enable row level security;
alter table public.media_channels enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.order_status_logs enable row level security;

-- profiles
create policy if not exists profiles_select_self_or_admin
on public.profiles
for select
using (auth.uid() = id or public.is_admin(auth.uid()));

create policy if not exists profiles_update_self_or_admin
on public.profiles
for update
using (auth.uid() = id or public.is_admin(auth.uid()));

create policy if not exists profiles_insert_self_or_admin
on public.profiles
for insert
with check (auth.uid() = id or public.is_admin(auth.uid()));

-- media_channels
create policy if not exists media_select_authenticated
on public.media_channels
for select
using (auth.role() = 'authenticated');

create policy if not exists media_admin_write
on public.media_channels
for all
using (public.is_admin(auth.uid()))
with check (public.is_admin(auth.uid()));

-- orders
create policy if not exists orders_select_self_or_admin
on public.orders
for select
using (member_id = auth.uid() or public.is_admin(auth.uid()));

create policy if not exists orders_insert_self_or_admin
on public.orders
for insert
with check (member_id = auth.uid() or public.is_admin(auth.uid()));

create policy if not exists orders_update_admin
on public.orders
for update
using (public.is_admin(auth.uid()));

-- order_items
create policy if not exists order_items_select_self_or_admin
on public.order_items
for select
using (
  exists (
    select 1
    from public.orders o
    where o.id = order_items.order_id
      and (o.member_id = auth.uid() or public.is_admin(auth.uid()))
  )
);

create policy if not exists order_items_admin_write
on public.order_items
for all
using (public.is_admin(auth.uid()))
with check (public.is_admin(auth.uid()));

-- order_status_logs
create policy if not exists order_logs_select_self_or_admin
on public.order_status_logs
for select
using (
  exists (
    select 1
    from public.orders o
    where o.id = order_status_logs.order_id
      and (o.member_id = auth.uid() or public.is_admin(auth.uid()))
  )
);

create policy if not exists order_logs_admin_write
on public.order_status_logs
for all
using (public.is_admin(auth.uid()))
with check (public.is_admin(auth.uid()));
