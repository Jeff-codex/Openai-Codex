# Supabase 연동 가이드 (딜리버)

## 1) 최상위 폴더 확인
- 프로젝트 최상위 폴더는 `딜리버(DELIVER)`로 고정.

## 2) 스키마 반영
- Supabase SQL Editor에서 실행 파일:
- `08_데이터베이스-Database/01_마이그레이션-Migrations/001_init_supabase_schema.sql`
- `08_데이터베이스-Database/01_마이그레이션-Migrations/002_create_deliver_table_with_rls.sql`

## 2-1) 테이블 URL 확인
- URL 자동 출력:
```bash
cd /mnt/c/Users/gusru/code/Openai-Codex/딜리버\(DELIVER\)
./07_자동화스크립트-AutomationScripts/supabase_urls.sh
```
- 출력 항목:
  - Supabase Dashboard Editor URL
  - `딜리버(Deliver)` 테이블 API URL(ASCII alias): `/rest/v1/deliver_table`
  - `딜리버(Deliver)` 테이블 API URL(raw quoted)

## 3) 환경변수 입력
- 파일: `01_서비스코드-ServiceCode/.env.supabase`
- 최소 입력값:
  - `SUPABASE_URL`
  - `SUPABASE_SERVICE_ROLE_KEY`

## 4) 현재 데이터 즉시 동기화
- 시드 데이터 파일:
  - `08_데이터베이스-Database/02_시드데이터-SeedData/media_channels.json`
- 실행:
```bash
cd /mnt/c/Users/gusru/code/Openai-Codex/딜리버\(DELIVER\)
./07_자동화스크립트-AutomationScripts/supabase_sync_seed.mjs
```

## 4-1) 동기화 전 필수 체크
- `public.media_channels`, `public.profiles`, `public.orders` 등 스키마 테이블이 먼저 생성되어 있어야 함
- 스키마 미적용 시 `PGRST205` 오류가 발생함

## 5) 동기화 로그 확인
- 폴더: `08_데이터베이스-Database/03_동기화로그-SyncLogs`

## 6) 관리자 권한 부여 (1회)
- SQL Editor에서 이메일 치환 후 실행:
```sql
insert into public.profiles (id, name, email, role)
select id, 'Admin', email, 'admin'
from auth.users
where email = 'your-email@example.com'
on conflict (id) do update
set role = 'admin';
```

## 7) RLS 정책 적용 확인
- SQL Editor에서 실행:
```sql
select schemaname, tablename, policyname, cmd
from pg_policies
where schemaname = 'public'
  and tablename in ('profiles', 'media_channels', 'orders', 'order_items', 'order_status_logs', '딜리버(Deliver)')
order by tablename, policyname;
```
