#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(scriptDir, '..');
const envPath = path.join(projectRoot, '01_서비스코드-ServiceCode', '.env.supabase');
const logDir = path.join(projectRoot, '08_데이터베이스-Database', '03_동기화로그-SyncLogs');
const seedDir = path.join(projectRoot, '08_데이터베이스-Database', '02_시드데이터-SeedData');

function parseEnv(filePath) {
  const map = {};
  if (!fs.existsSync(filePath)) return map;
  const lines = fs.readFileSync(filePath, 'utf8').split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const idx = trimmed.indexOf('=');
    if (idx < 0) continue;
    const key = trimmed.slice(0, idx).trim();
    const value = trimmed.slice(idx + 1).trim();
    map[key] = value;
  }
  return map;
}

function loadJson(filePath, fallback = []) {
  if (!fs.existsSync(filePath)) return fallback;
  const text = fs.readFileSync(filePath, 'utf8').trim();
  if (!text) return fallback;
  return JSON.parse(text);
}

function nowStamp() {
  const d = new Date();
  const pad = (v) => String(v).padStart(2, '0');
  return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

async function restUpsert({ url, serviceRoleKey, table, rows, conflict }) {
  if (!rows.length) return { table, count: 0, skipped: true };

  const endpoint = `${url}/rest/v1/${table}?on_conflict=${encodeURIComponent(conflict)}`;
  const res = await fetch(endpoint, {
    method: 'POST',
    headers: {
      apikey: serviceRoleKey,
      Authorization: `Bearer ${serviceRoleKey}`,
      'Content-Type': 'application/json',
      Prefer: 'resolution=merge-duplicates,return=representation',
    },
    body: JSON.stringify(rows),
  });

  const bodyText = await res.text();
  if (!res.ok) {
    throw new Error(`[${table}] ${res.status} ${res.statusText} - ${bodyText}`);
  }

  let parsed = [];
  try {
    parsed = bodyText ? JSON.parse(bodyText) : [];
  } catch {
    parsed = [];
  }

  return { table, count: parsed.length, skipped: false };
}

async function run() {
  const envFile = parseEnv(envPath);
  const SUPABASE_URL = process.env.SUPABASE_URL || envFile.SUPABASE_URL || '';
  const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || envFile.SUPABASE_SERVICE_ROLE_KEY || '';

  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY. Fill 01_서비스코드-ServiceCode/.env.supabase first.');
  }

  const mediaChannels = loadJson(path.join(seedDir, 'media_channels.json'));
  const orders = loadJson(path.join(seedDir, 'orders.json'));
  const orderLogs = loadJson(path.join(seedDir, 'order_status_logs.json'));

  const results = [];
  results.push(
    await restUpsert({
      url: SUPABASE_URL,
      serviceRoleKey: SUPABASE_SERVICE_ROLE_KEY,
      table: 'media_channels',
      rows: mediaChannels,
      conflict: 'name',
    })
  );
  results.push(
    await restUpsert({
      url: SUPABASE_URL,
      serviceRoleKey: SUPABASE_SERVICE_ROLE_KEY,
      table: 'orders',
      rows: orders,
      conflict: 'id',
    })
  );
  results.push(
    await restUpsert({
      url: SUPABASE_URL,
      serviceRoleKey: SUPABASE_SERVICE_ROLE_KEY,
      table: 'order_status_logs',
      rows: orderLogs,
      conflict: 'id',
    })
  );

  fs.mkdirSync(logDir, { recursive: true });
  const logPath = path.join(logDir, `supabase-sync-${nowStamp()}.json`);
  fs.writeFileSync(logPath, JSON.stringify({ syncedAt: new Date().toISOString(), results }, null, 2), 'utf8');

  console.log('[OK] Supabase seed sync completed');
  console.log(`[OK] Log file: ${logPath}`);
  for (const row of results) {
    if (row.skipped) {
      console.log(`- ${row.table}: skipped (no rows)`);
    } else {
      console.log(`- ${row.table}: upserted ${row.count} rows`);
    }
  }
}

run().catch((error) => {
  console.error('[ERROR] Supabase seed sync failed');
  console.error(error.message || error);
  if (String(error.message || '').includes('PGRST205')) {
    console.error(
      '[HINT] Supabase SQL Editor에서 001_init_supabase_schema.sql 과 002_create_deliver_table_with_rls.sql 을 순서대로 먼저 실행해 주세요.'
    );
  }
  process.exit(1);
});
