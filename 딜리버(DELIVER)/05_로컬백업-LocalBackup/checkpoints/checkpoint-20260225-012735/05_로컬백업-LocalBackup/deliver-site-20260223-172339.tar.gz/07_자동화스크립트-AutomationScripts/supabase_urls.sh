#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_PATH="$PROJECT_ROOT/01_서비스코드-ServiceCode/.env.supabase"

if [[ ! -f "$ENV_PATH" ]]; then
  echo "[ERROR] Missing env file: $ENV_PATH"
  exit 1
fi

SUPABASE_URL="$(grep -E '^SUPABASE_URL=' "$ENV_PATH" | head -n1 | cut -d= -f2- || true)"
if [[ -z "$SUPABASE_URL" ]]; then
  echo "[ERROR] SUPABASE_URL is empty in $ENV_PATH"
  exit 1
fi

PROJECT_REF="$(echo "$SUPABASE_URL" | sed -E 's#https://([^.]+)\.supabase\.co#\1#')"

RAW_TABLE_URL="$SUPABASE_URL/rest/v1/%22%EB%94%9C%EB%A6%AC%EB%B2%84%28Deliver%29%22"
ALIAS_TABLE_URL="$SUPABASE_URL/rest/v1/deliver_table"
DASHBOARD_EDITOR_URL="https://supabase.com/dashboard/project/$PROJECT_REF/editor"

cat <<TXT
[SUPABASE URLS]
- Project URL: $SUPABASE_URL
- Dashboard Editor: $DASHBOARD_EDITOR_URL
- Table API URL (alias): $ALIAS_TABLE_URL
- Table API URL (quoted raw): $RAW_TABLE_URL
TXT
