-- 딜리버(Deliver) 전용 운영 테이블 + RLS
-- 사전 조건: 001_init_supabase_schema.sql 실행 완료

create table if not exists public."딜리버(Deliver)" (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('member', 'order', 'media', 'log', 'config')),
  title text not null,
  payload jsonb not null default '{}'::jsonb,
  is_active boolean not null default true,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

comment on table public."딜리버(Deliver)" is '딜리버 프로젝트 통합 운영 데이터 테이블';

create index if not exists idx_deliver_table_kind
  on public."딜리버(Deliver)" (kind);

create index if not exists idx_deliver_table_is_active
  on public."딜리버(Deliver)" (is_active);

create index if not exists idx_deliver_table_created_at
  on public."딜리버(Deliver)" (created_at desc);

drop trigger if exists trg_deliver_table_touch_updated_at on public."딜리버(Deliver)";
create trigger trg_deliver_table_touch_updated_at
before update on public."딜리버(Deliver)"
for each row execute function public.touch_updated_at();

alter table public."딜리버(Deliver)" enable row level security;

-- 관리자만 조회/쓰기
-- 필요 시 멤버 조회 허용 정책을 별도 추가

drop policy if exists deliver_table_admin_select on public."딜리버(Deliver)";
create policy deliver_table_admin_select
on public."딜리버(Deliver)"
for select
using (public.is_admin(auth.uid()));

drop policy if exists deliver_table_admin_insert on public."딜리버(Deliver)";
create policy deliver_table_admin_insert
on public."딜리버(Deliver)"
for insert
with check (public.is_admin(auth.uid()));

drop policy if exists deliver_table_admin_update on public."딜리버(Deliver)";
create policy deliver_table_admin_update
on public."딜리버(Deliver)"
for update
using (public.is_admin(auth.uid()))
with check (public.is_admin(auth.uid()));

drop policy if exists deliver_table_admin_delete on public."딜리버(Deliver)";
create policy deliver_table_admin_delete
on public."딜리버(Deliver)"
for delete
using (public.is_admin(auth.uid()));

-- API 접근 편의를 위한 ASCII alias view
create or replace view public.deliver_table as
select * from public."딜리버(Deliver)";

alter view public.deliver_table set (security_invoker = on);
